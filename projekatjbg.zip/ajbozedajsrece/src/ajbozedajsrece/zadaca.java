package ajbozedajsrece;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import java.util.Random;
import java.awt.ActiveEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;

import javax.swing.JButton;

public class zadaca extends KeyAdapter {

	public static void main(String[] args) {
		frame();
		

	}

	



public static void frame() {

	JFrame f=new JFrame("NO NAME GAME");
	f.setVisible(true);
	f.setSize(1000,600);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	JPanel p=new JPanel();
	JButton b1=new JButton("NEW GAME");
	JButton b2=new JButton("SAVE");
	JButton b3=new JButton("LOAD");
	JButton b4=new JButton("EXIT");
	b1.addActionListener(new ActionListener()
	{
         public void actionPerformed(ActionEvent e) {
        	 f.setVisible(false);
        	 JFrame f1=new JFrame("NEW GAME");
        	 f1.setSize(800,600);
        		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        	 f1.setVisible(true);
        	 JTextPane tp=new JTextPane();
        	 SimpleAttributeSet attributeSet = new SimpleAttributeSet();  
             StyleConstants.setBold(attributeSet, true);  
        	 tp.setCharacterAttributes(attributeSet, true);  
             tp.setText("Please enter dimensions of the field, x and y values should be seperated by comma, ");
             tp.setBounds(30,100,200,120);
        	 TextField jt= new TextField(); 
        	 jt.setBounds(10,10,270,50);
        	 JPanel panel = new JPanel();
             panel.setLayout(new FlowLayout());
        	 JButton b5=new JButton("START");
            
        	 b5.setBounds(300,10,100,50);
        	 f1.add(tp);
        	 f1.add(b5);
        	 f1.add(jt);
        	 f1.add(panel);

        	 f.dispose();
        	 b5.addActionListener(new ActionListener()
        			 {
						public void actionPerformed(ActionEvent e) {
							String jttxt = jt.getText();
							int res=0;
							int ress = 0;
							for(String s : jttxt.split(","))
							{
								if(res!=0) {
									ress=Integer.parseInt(s);
								}
								else
								res = Integer.parseInt(s);
								
							}
							JButton[][] buttons = new JButton[res][ress];
							int rr=res*ress;
							 f1.setVisible(false);
				        	 JFrame f2=new JFrame("NEW GAME");
				        	 f2.setSize(800,600);
				        		f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				        	 f2.setVisible(true);
				 			f2.setLayout(new GridLayout(res,ress));
				        	 for(int i=0;i<res;i++) {
				        		 for(int j=0;j<ress;j++) {
				        			 Random rand = new Random();
				        			 int rend = rand.nextInt(5); 
				        			 buttons[i][j]=new JButton("");
				        			if(rend==1) buttons[i][j].setBackground(Color.RED);
				        			if(rend==0) buttons[i][j].setBackground(Color.blue);
				        			if(rend==2) buttons[i][j].setBackground(Color.green);
				        			if(rend==3) buttons[i][j].setBackground(Color.yellow);
				        			if(rend==4) buttons[i][j].setBackground(Color.white);
				        			 f2.add(buttons[i][j]);
					        	 }
				        	 }
				        	 int f1=ress;
				        	 int k1=res;
				        	int clicked = 0;
				        	int fww=keypressed(null);
				        


	for(int i=0;i<res;i++) { 
		for(int j=0;j<ress;j++) { int k=i; int f=j;
				        	 buttons[i][j].addActionListener(new ActionListener() {

				        		 
								public void actionPerformed(ActionEvent e) {


		                            if(buttons[k][f].getBackground()!=Color.blue)
									buttons[k][f].setBackground(Color.blue);
		                            else {

		                            	 buttons[k-1][f].setBackground(Color.blue);
		                            	 buttons[k][f-1].setBackground(Color.blue);
		                            	 buttons[k+1][f].setBackground(Color.blue);
		                            	 buttons[k][f+1].setBackground(Color.blue);
		                            	 buttons[k+1][f+1].setBackground(Color.blue);
		                            	 buttons[k-1][f-1].setBackground(Color.blue);
		                            	 buttons[k+1][f-1].setBackground(Color.blue);
		                            	 buttons[k-1][f+1].setBackground(Color.blue);
		                            	buttons[k][f].setBackground(Color.blue);

		                            }
									
								}
				        		 
				        	 }
				        			 
				        			 );	 
				        	 } }
	Timer timer1 = new Timer();
	Timer timer2 = new Timer();
	int q=res;
	int w=ress;
	TimerTask task1= new TimerTask() {

		
		public void run() {
			int wat=0;
			for(int i=0;i<q;i++)
			{
				for(int j=0;j<w;j++)
				{
					if(buttons[i][j].getBackground()==Color.blue)
						wat=wat+1;
				}
			}
			if(wat==w*q) {
			JFrame f5=new JFrame("GG");
			f2.setVisible(false);
			f5.setVisible(true);
			f5.setSize(100,100);
			JLabel wq=new JLabel("You win");
			f5.add(wq);
			f2.dispose();
			timer1.cancel();
			timer2.cancel();
			}
		}
		
	};
TimerTask task2= new TimerTask() {

		
		public void run() {
			JFrame f6=new JFrame("LOSER");
			f2.setVisible(false);
			f6.setVisible(true);
			f6.setSize(150,150);
			JLabel wq=new JLabel("Ya suck");

			f6.add(wq);
			f2.dispose();
			timer2.cancel();
			
		}
		
	};
	timer1.scheduleAtFixedRate(task1, 100, 1000);
	timer2.schedule(task2, 30000);
			;


	

						}

						private int keypressed(KeyEvent e)
     		{
     			int keyCode=e.getKeyCode();
     			if(keyCode==e.VK_F2)
     				return 1;
     			else 
     			return 0;
						}
						
        		 
        			 });
        			

			
		}
     

		
	});
	

	b4.addActionListener(new ActionListener()
	{
         public void actionPerformed(ActionEvent e) {
        	 f.setVisible(false);
        	 f.dispose();
        	 
			
		}

		
	});
	
	p.add(b1);
	p.add(b2);
	p.add(b3);
	p.add(b4);
	f.add(p);
	
}


}


